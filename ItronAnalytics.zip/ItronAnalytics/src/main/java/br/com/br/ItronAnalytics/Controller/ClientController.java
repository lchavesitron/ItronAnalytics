package br.com.br.ItronAnalytics.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientController {
	
	@RequestMapping("/")
	public void find() {
		System.out.println("Chamou");
	}

}
